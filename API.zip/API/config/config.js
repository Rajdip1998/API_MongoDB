const {v4:uuidv4}= require('uuid');

exports.configuration = (method,request,data,bank,key)=>{
  let digit = bank === "a"? 0 :bank === "b"?1:null;
const config = {
  'method': method,
  'url': `https://asset-platform.mtn-stg.eap.kaleido.io/api/v1/namespaces/innovation/apis/mtntoken-99900${digit}-gbp${bank}${request}`,
  'headers': {
    'Authorization': 'Basic aW5ub3Ytc3ByaW50LWViMTNmOGFiYzU6NzkzMzk4MzAtZDg0MC00MjczLTk4YTItNTBjMzNmYzFmYTQ1LWY2NDRiNGY1LTE5ODItNGZlNC05OTU2LTNhZTY4MzI3MWQzOQ==',
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({"idempotencyKey":uuidv4(),"input":data,"key":key,"options":{}})
};
return config;
}
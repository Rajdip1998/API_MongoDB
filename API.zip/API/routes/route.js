const {Router} = require('express');
const controllers = require('../controllers/controller');

const router = Router();

router.post('/balance',controllers.getBalance);
router.post('/transfer',controllers.transferMoney);

module.exports = router;
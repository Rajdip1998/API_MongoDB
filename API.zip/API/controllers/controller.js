const request = require('request');
const {configuration} = require('../config/config');

exports.getBalance = (req,res)=>{
  const {account,bank} = req.body;
  const data = {"account":account};
  const config = configuration('POST','/query/balanceOf',data,bank,account);
  
  request(config, function (error, response) {
    if (error){
      res.send({error:new Error(error)});
    }else{
      res.send({result:JSON.parse(response.body)});
    }
  });
}

exports.transferMoney = (req,res)=>{
  const {from,to,amount,bank}=req.body;
  const data = {"amount":amount,"to":to};
  const config = configuration('POST','/invoke/transfer',data,bank,from);
  
  request(config, function (error, response) {
    if (error){
      res.send({error:new Error(error)});
    }else{
      res.send({result:JSON.parse(response.body)});
    }
  });
}


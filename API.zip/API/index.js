const express = require('express');
const cors = require('cors');
const controllerRoutes = require('./routes/route');

const app = express();

const port = 1998;

app.use(express.json());
app.use(cors());

app.use('/',controllerRoutes);

app.listen(port,()=>console.log(`API is running at PORT ${port}`));